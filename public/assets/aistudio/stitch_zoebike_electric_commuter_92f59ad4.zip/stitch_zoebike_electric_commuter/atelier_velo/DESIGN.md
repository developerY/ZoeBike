---
name: Atelier Velo
colors:
  surface: '#fcf9f6'
  surface-dim: '#dcdad7'
  surface-bright: '#fcf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f0'
  surface-container: '#f0edea'
  surface-container-high: '#eae8e5'
  surface-container-highest: '#e5e2df'
  on-surface: '#1c1c1a'
  on-surface-variant: '#56423c'
  inverse-surface: '#31302f'
  inverse-on-surface: '#f3f0ed'
  outline: '#8a726a'
  outline-variant: '#ddc0b7'
  surface-tint: '#a0401c'
  primary: '#9d3e1a'
  on-primary: '#ffffff'
  primary-container: '#bd5630'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb59c'
  secondary: '#1f6966'
  on-secondary: '#ffffff'
  secondary-container: '#a7ece8'
  on-secondary-container: '#246d6a'
  tertiary: '#7f4d5f'
  on-tertiary: '#ffffff'
  tertiary-container: '#9b6577'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcf'
  primary-fixed-dim: '#ffb59c'
  on-primary-fixed: '#390c00'
  on-primary-fixed-variant: '#802a05'
  secondary-fixed: '#aaefeb'
  secondary-fixed-dim: '#8ed3cf'
  on-secondary-fixed: '#00201f'
  on-secondary-fixed-variant: '#00504e'
  tertiary-fixed: '#ffd9e3'
  tertiary-fixed-dim: '#f5b5c9'
  on-tertiary-fixed: '#340e1e'
  on-tertiary-fixed-variant: '#673849'
  background: '#fcf9f6'
  on-background: '#1c1c1a'
  surface-variant: '#e5e2df'
typography:
  headline-xl:
    fontFamily: Outfit
    fontSize: 3.5rem
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Outfit
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: '1.15'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Outfit
    fontSize: 2.5rem
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Outfit
    fontSize: 1.75rem
    fontWeight: '500'
    lineHeight: '1.25'
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Outfit
    fontSize: 1.75rem
    fontWeight: '500'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Outfit
    fontSize: 1.25rem
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: '1.55'
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: 0em
  label-lg:
    fontFamily: Outfit
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.04em
  label-md:
    fontFamily: Outfit
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Outfit
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.08em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-desktop: 2.5rem
  margin: 1.25rem
  margin-tablet: 2.5rem
  margin-desktop: 4rem
  space-xs: 0.375rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 2rem
  space-xl: 3.5rem
---

## Brand & Style

This design system delivers an elevated, fashion-forward mobility experience tailored for urban commuters and modern women who view their electric bicycle not simply as transportation, but as an extension of personal style and joyful routine.

### Brand Personality & Emotional Atmosphere
- **Airy & Sculptural:** Layouts celebrate negative space, sunlit breathing room, and intentional composition over dense utility.
- **Warmly Sophisticated:** Deviates from aggressive, tech-heavy electric vehicle tropes in favor of soft textures, champagne creams, and tactile warmth.
- **Playful Empowerment:** Balancing effortless luxury with approachable, lighthearted micro-moments that make commuting feel uplifting and fluid.

### Design Direction: Contemporary Soft-Sculptural Minimalist
Drawing from modern luxury editorial and soft-industrial product design, the interface pairs pill-shaped geometry, translucent frosted surfaces, and nuanced organic tones with crisp editorial typography. Visual density remains light, favoring generous gutters, bespoke specification meters, and floating navigational elements.

## Colors

The palette grounds itself in warm, light-reflective mineral tones contrasted against sharp botanical charcoals.

### Role Assignments & Surface Strategy
- **Canvas & Backdrops:** Surfaces rest on Champagne Cream (`#FAF7F4`) and warm alabaster (`#F5EFEB`), preventing the clinical sterility of pure white.
- **Primary Accent (Warm Terracotta / `#D96B43`):** Reserved for primary interactive touchpoints, hero checkouts, reservation calls-to-action, and critical battery milestones.
- **Secondary Accent (Glacier Sage / `#5A9E9B`):** Applied to ecological metrics, regenerative braking indicators, smooth transit states, and secondary toggles.
- **Tertiary Accent (Muted Rose Lilac / `#B47B8E`):** Enhances curated accessory collections, customization tags, and lifestyle feature callouts.
- **Ink & Typography:** High-contrast Charcoal Moss (`#1F2421`) for all primary titles and deep body text, maintaining WCAG AAA legibility. Subordinate captions and supporting meta-details use Muted Slate Charcoal (`#4A534E`).
- **Container Surfaces:** Elevated cards use a crisp semi-translucent soft cream (`rgba(255, 255, 255, 0.72)`) backed with subtle blurs to highlight product silhouettes.

## Typography

The typographic hierarchy pairs the soft, sculpted geometry of **Outfit** for headlines and interactive chips with the pristine utilitarian rhythm of **Inter** for descriptions, specifications, and telemetry data.

### Typographic Principles
- **Title Tracking & Optical Sizing:** Large headlines leverage tight letter-spacing (`-0.03em`) to create an editorial lockup that emulates contemporary high-fashion lookbooks.
- **Body Air:** Body text uses an open line-height of `1.55` to `1.6` with Inter to preserve an effortless, easy-to-read cadence across ride statistics and product stories.
- **Labels & Micro-copy:** Labels adopt uppercase styling with slight letter-spacing (`0.04em` - `0.08em`) to act as refined anchors on specification badges and bike parameter chips.

## Layout & Spacing

The layout philosophy is founded on an asymmetric, fluid grid system designed to frame hardware imagery like gallery artifacts.

### Responsive Structure
- **Mobile (< 768px):** 4-column fluid grid, `1.25rem` outer canvas margin, `1.5rem` gutter. Cards stretch full width or align to horizontally scrolling carousels with peek margins.
- **Tablet (768px – 1024px):** 8-column grid, `2.5rem` outer margin, `1.5rem` gutter. Side-by-side spec layouts emerge with pinned sticky preview frames.
- **Desktop (> 1024px):** 12-column grid, `4rem` outer margin, `2.5rem` gutter. Restrained maximum content width of `1360px` to guarantee balanced reading lengths alongside full-height studio visuals.

### Spacing Philosophy
Rhythms follow generous vertical separations. Product showcases and narrative blocks utilize `space-xl` (`3.5rem`) to create an unhurried, luxury salon browsing experience. Component interiors maintain compact padding ratios (`space-sm` to `space-md`) to ensure controls remain distinct and tactile.

## Elevation & Depth

Visual depth avoids dense black dropshadows, relying instead on ambient, tinted atmospheric layers and soft light diffusion.

### Ambient Warm Shadows
Surfaces float on warm, multi-layered shadows tinted by the cream and terracotta environment:
- **Resting Cards:** `0 4px 20px -2px rgba(44, 53, 49, 0.04), 0 2px 6px -1px rgba(217, 107, 67, 0.02)`
- **Floating Controls & Active Modals:** `0 16px 40px -6px rgba(44, 53, 49, 0.08), 0 6px 16px -2px rgba(217, 107, 67, 0.05)`

### Frosted Translucency (Luminous Glass)
Sticky navigation headers, bike telemetry HUDs, and bottom control sheets employ a frosted surface effect:
- **Treatment:** `background: rgba(250, 247, 244, 0.82)` with `backdrop-filter: blur(16px)` and a whisper-thin outline `1px solid rgba(255, 255, 255, 0.6)`.

## Shapes

The design language embodies organic fluidity, honoring the aerodynamic yet sculptural curves of modern step-through e-bike tubing.

### Geometry Hierarchy
- **Pills & Capsular Elements:** All interactive buttons, status badges, ride-mode switchers, and filter pills employ full rounded caps (`9999px` / Level 3).
- **Cards & Structural Enclosures:** Major containers, product cards, and feature drawers use generous radius corners (`rounded-xl` / `3rem`) creating a welcoming, humanized boundary.
- **Internal Micro-controls:** Steppers, segmented track bars, and small input fields use `1rem` radius, harmonizing with outer capsular containers.

## Components

### Buttons
- **Primary Button:** Pill-shaped (`rounded-full`), clad in Terracotta (`#D96B43`) with Crisp Cream text (`#FAF7F4`). Height is `52px` on mobile and `56px` on desktop. Active press states trigger an elastic scale down (`scale(0.98)`).
- **Secondary Button:** Frosted Alabaster container (`#F5EFEB`) with Charcoal Moss text (`#1F2421`) and an ultra-fine border (`1px solid rgba(31, 36, 33, 0.08)`).
- **Icon Action Buttons:** `48px` circular floating capsules holding minimal 1.5px stroke icons (heart/save, lock/unlock, headlight toggle).

### Badges & Chips
- **Specification Badges:** Slender pill shapes containing uppercase `label-md` tracking. Color-coded per context:
  - *Battery & Range:* Soft Mint background (`rgba(90, 158, 155, 0.12)`) with Glacier Sage text (`#3B7370`).
  - *Model Edition:* Soft Blush background (`rgba(180, 123, 142, 0.12)`) with Deep Rose text (`#874F61`).

### Input Fields
- **Search & Text Inputs:** Pill-shaped or heavily rounded (`1.25rem`), filled with warm alabaster (`#F5EFEB`). Floating labels transition to `label-sm` in Charcoal Slate. Zero harsh borders at rest; focused state presents a soft `2px` ring in Terracotta at 40% opacity.

### Selection Controls (Checkboxes & Radios)
- **Radio Color Pickers:** Custom circular swatches (`36px`) ringed with a white offset separator and a dynamic outer halo indicating the selected bike chassis colorway (e.g., Peach Bloom, Sage Whisper, Raw Linen).
- **Checkboxes:** Smooth rounded squares (`8px` corner radius) with Terracotta fill and clean white micro-checkmark iconography.

### Cards & Configuration Modules
- **Vehicle Showroom Card:** Asymmetrical layout balancing large silhouette photography against generous margins. Contains floating pill tags for weight and motor wattage. Cards transition on hover with a gentle upward translation (`-4px`) and expanded ambient shadow.
- **Range & Speed Slider:** Continuous custom track with a soft sage fill, featuring an oversized circular thumb (`28px`) that reflects current assist mode via micro-vibrations.